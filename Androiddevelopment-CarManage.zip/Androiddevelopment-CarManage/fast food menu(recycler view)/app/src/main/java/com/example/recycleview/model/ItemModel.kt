package com.example.recycleview.model

data class ItemModel(val image: Int, val name: String, val price: String)