package com.ffan.roomdatabaseapp.utils

class Resource {
}